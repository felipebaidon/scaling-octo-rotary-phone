#include <stdio.h>

int main()
{
	int ch;

	printf("Type a character: ");
	ch = getchar();
	printf("Character '%c' received.\n",ch);

	return(0);
}
