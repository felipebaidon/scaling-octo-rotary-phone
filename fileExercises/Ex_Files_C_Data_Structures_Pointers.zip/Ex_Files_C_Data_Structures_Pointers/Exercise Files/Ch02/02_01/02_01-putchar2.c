#include <stdio.h>

int main()
{
	putc('H',stdout);
	putc('e',stdout);
	putc('l',stdout);
	putc('l',stdout);
	putc('o',stdout);
	putc('\n',stdout);

	return(0);
}

