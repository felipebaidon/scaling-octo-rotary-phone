#include <stdio.h>

int main()
{
	printf("Hello, Earth!");

	return(0);
}

