#include <stdio.h>

int main()
{
	printf("Hello, Earth!\n");
	printf("%s","Hello, Moon!\n");

	return(0);
}

