#include <stdio.h>

int main()
{
	char string[] = "Yet another string literal";

	puts("A string literal");
	puts(string);

	return(0);
}

