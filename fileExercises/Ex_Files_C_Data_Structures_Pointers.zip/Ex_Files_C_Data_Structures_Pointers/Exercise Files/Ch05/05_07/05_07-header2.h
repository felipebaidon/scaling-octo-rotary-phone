/* header file */
#include <stdlib.h>
#include <time.h>

#define MAX 100
#define SIZE 3

struct data {
	int a;
	char b;
};

